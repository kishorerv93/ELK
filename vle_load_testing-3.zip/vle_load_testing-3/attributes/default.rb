default[:vle_load_testing][:jmeter][:vesion] = 3.3
default[:vle_load_testing][:jmeter][:home] = "/usr/local/apache-jmeter-#{node[:vle_load_testing][:jmeter][:vesion]}"

default[:vle_load_testing][:jmeter_plugins_manager][:vesion] = 0.16
default[:vle_load_testing][:jmeter_plugins_manager][:jar] = "jmeter-plugins-manager-#{node[:vle_load_testing][:jmeter_plugins_manager][:vesion]}.jar"
default[:vle_load_testing][:jmeter_plugins_dir] = "#{node[:vle_load_testing][:jmeter][:home]}/lib/ext"

default[:vle_load_testing][:jmeter_daemon][:app_id] = 'a88c27fc7893342b4f88a79cbd22e720ca478193fd433419c527497d9a26ede7'
default[:vle_load_testing][:jmeter_daemon][:app_secret] = '3f0c0e1ef3767ecbd8fa79f12c548370b958013624b9d1cea4a0ee6ec112d7ce'
default[:vle_load_testing][:jmeter_daemon][:java_rmi_server_logCalls] = true
default[:vle_load_testing][:jmeter_daemon][:jmeterlogfile] = '/opt/load-testing/jMeter/log/jmeter.log'
default[:vle_load_testing][:jmeter_daemon][:logfile] = '/opt/load-testing/jMeter/log/results.log'
default[:vle_load_testing][:jmeter_daemon][:console_log] = '/opt/load-testing/jMeter/log/console.log'
default[:vle_load_testing][:jmeter_daemon][:server_rmi_localport] = 60000
default[:vle_load_testing][:jmeter_daemon][:stack_id] = 'load'
default[:vle_load_testing][:jmeter_daemon][:testfile] = '/opt/load-testing/jMeter/canvas_happy.jmx'
default[:vle_load_testing][:jmeter_daemon][:extra_args] = ""
