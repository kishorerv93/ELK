name        "vle_load_testing"
description "Load testing Chef recipes"
maintainer  "devops@videri.com"
version     "1.0.0"

supports 'ubuntu'
