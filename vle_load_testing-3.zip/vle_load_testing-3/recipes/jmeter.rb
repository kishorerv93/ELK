package 'wget'
package 'tar'

# Install jMeter
apache_jmeter_tgz_file = "apache-jmeter-#{node[:vle_load_testing][:jmeter][:vesion]}.tgz"
downloaded_apache_jmeter_tgz_path = "/tmp/#{apache_jmeter_tgz_file}"
remote_file downloaded_apache_jmeter_tgz_path do
  source "https://archive.apache.org/dist/jmeter/binaries/#{apache_jmeter_tgz_file}"
end
execute "tar -xzf #{downloaded_apache_jmeter_tgz_path} -C /usr/local/"

# Install plugins manager
downloaded_jmeter_plugins_manager_jar_path = "#{node[:vle_load_testing][:jmeter_plugins_dir]}/#{node[:vle_load_testing][:jmeter_plugins_manager][:jar]}"
remote_file downloaded_jmeter_plugins_manager_jar_path do
  source "http://search.maven.org/remotecontent?filepath=kg/apc/jmeter-plugins-manager/#{node[:vle_load_testing][:jmeter_plugins_manager][:vesion]}/#{node[:vle_load_testing][:jmeter_plugins_manager][:jar]}"
end

downloaded_cmdrunner_jar_path = "#{node[:vle_load_testing][:jmeter][:home]}/lib/cmdrunner-2.0.jar"
remote_file downloaded_cmdrunner_jar_path do
  source 'https://search.maven.org/remotecontent?filepath=kg/apc/cmdrunner/2.0/cmdrunner-2.0.jar'
end

execute "java -cp #{downloaded_jmeter_plugins_manager_jar_path} org.jmeterplugins.repository.PluginManagerCMDInstaller"

# Install XMPP plugin (must run from absolute path due to relative path in code)
#execute "#{node[:vle_load_testing][:jmeter][:home]}/bin/PluginsManagerCMD.sh install jpgc-xmpp=1.5.1"
