git_ssh_key = '/root/.ssh/load-testing-jmeter'

cookbook_file git_ssh_key do
  source 'load-testing-jmeter'
  owner 'root'
  group 'root'
  mode '0400'
end

script 'jmeter_daemon' do
  interpreter "bash"
  code <<-EOH
    DEVICE_ID_CSV_INDEX=$(echo $HOSTNAME | awk -F'server' '{print $2}')
    GIT_SSH_KEY="#{git_ssh_key}"
    echo 'ssh -i '"$GIT_SSH_KEY"' -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $*' > /tmp/load_testing_ssh
    chmod +x /tmp/load_testing_ssh
    if [ -d "/opt/load-testing" ]; then
      cd /opt/load-testing
      GIT_SSH='/tmp/load_testing_ssh' git pull
    else
      GIT_SSH='/tmp/load_testing_ssh' git clone git@git.videri.com:vle/load-testing.git /opt/load-testing
    fi
    mkdir -p /opt/load-testing/jMeter/log
    cd /opt/load-testing/jMeter
    /usr/local/apache-jmeter-3.3/bin/jmeter \
      --jmeterproperty app_id=#{node[:vle_load_testing][:jmeter_daemon][:app_id]} \
      --jmeterproperty app_secret=#{node[:vle_load_testing][:jmeter_daemon][:app_secret]} \
      --jmeterproperty stack_id=#{node[:vle_load_testing][:jmeter_daemon][:stack_id]} \
      --jmeterproperty dataset_file_index=$DEVICE_ID_CSV_INDEX \
      --jmeterlogfile #{node[:vle_load_testing][:jmeter_daemon][:jmeterlogfile]} \
      --logfile #{node[:vle_load_testing][:jmeter_daemon][:logfile]} \
      --server \
      --systemproperty java.rmi.server.hostname="#{node[:opsworks][:instance][:private_ip]}" \
      --systemproperty java.rmi.server.logCalls=#{node[:vle_load_testing][:jmeter_daemon][:java_rmi_server_logCalls]} \
      --systemproperty server.rmi.localport=#{node[:vle_load_testing][:jmeter_daemon][:server_rmi_localport]} \
      #{node[:vle_load_testing][:jmeter_daemon][:extra_args]} \
      > #{node[:vle_load_testing][:jmeter_daemon][:console_log]} 2>&1 \
      &
  EOH
  not_if 'pgrep -x "jmeter" > /dev/null'
end
